# fb-maker
Buat akun fb


cara install di termux :

-apt update && apt upgrade

-pkg install git

-pkg install python2

-git clone https://github.com/tri-hermawan/fb-maker

-pip2 install mechanize

-pip2 install requests

-pip2 install bs4


cara jalanin nya :

-cd fb-maker

-python2 fb-maker.py -c [jumlah/count akun yg mau di buat]

contoh : python2 fb-maker.py -c 10




NB :

Kalo kena Checkpoint Tinggal tambahin no hp.
